# Tugas Akhir Kelas Belajar Backend Pemula - Dicoding
kelas diperoleh dari beasiswa DevOps & Backend Developer Scholarship 2022 oleh Dicoding dan AWS

## Deskripsi tugas
membuat aplikasi Bookshelf API
link repository github :
```
https://github.com/rikiwidiantoro/dicoding-beasiswa-backend-dev22/tree/main/tugas-akhir/bookshelf-api
```

## Tools yg digunakan
- Framework Node.js : Hapi
- ESLint
- node version : v16.16.0
- npm version : 8.19.2

### Catatan
Jika melakukan pengujian pertama ada yang error, maka lakukan pengujian kembali dengan klik "Run Again". Karena saya juga mengalami kendala tersebut dan selanjutnya berhasil alias tidak ada error sama sekali, berikut screenshoot hasil pengujian pada Postman :
```
https://drive.google.com/drive/folders/1NTM6JfHkhy8hXaXdnSXiwUDxmHiCEwJA?usp=sharing
```